import asyncio
import json
import sys
from pyrogram import Client, enums

API_ID = 29157424
API_HASH = "0a43c855cd71585eed46f3376669a195"
PHONE_NUMBER = "+18633162410"

async def countdown(seconds):
    for remaining in range(seconds, 0, -1):
        sys.stdout.write(f"\rResuming in {remaining} seconds...")
        sys.stdout.flush()
        await asyncio.sleep(1)
    sys.stdout.write("\r" + " " * 30 + "\r")  # Clear the line
    sys.stdout.flush()

async def main():
    async with Client("my_account", API_ID, API_HASH, phone_number=PHONE_NUMBER) as app:
        print("Successfully logged in!")

        groups = []
        async for dialog in app.get_dialogs():
            if dialog.chat.type in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
                groups.append(dialog.chat)

        if not groups:
            print("You are not a member of any groups or supergroups.")
            return

        print("\nAvailable Groups:")
        for i, group in enumerate(groups, 1):
            print(f"{i}. {group.title}")

        while True:
            try:
                choice = int(input("\nEnter the number of the group you want to save messages from: "))
                if 1 <= choice <= len(groups):
                    selected_group = groups[choice - 1]
                    break
                else:
                    print("Invalid choice. Please try again.")
            except ValueError:
                print("Please enter a valid number.")

        print(f"\nFetching all messages from {selected_group.title}...")

        messages = []
        message_count = 0
        filename = f"{selected_group.title.replace(' ', '_')}_messages.json"

        async for message in app.get_chat_history(selected_group.id):
            sender = message.from_user.first_name if message.from_user else "Unknown"
            content = message.text or message.caption or "Media message"
            messages.append({
                "sender": sender,
                "content": content,
                "date": message.date.isoformat()
            })
            message_count += 1

            if message_count % 100 == 0:
                print(f"Fetched {message_count} messages. Saving to file and pausing for 2 minutes...")
                save_to_json(messages, filename)
                await countdown(120)

        if messages:
            save_to_json(messages, filename)

        print(f"All messages saved to {filename}")

def save_to_json(messages, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(messages, f, ensure_ascii=False, indent=4)

if __name__ == "__main__":
    asyncio.run(main())
